import { SEED_EVENT_TOPICS } from '../services/eventInterests'
import type { CommunityEvent } from '../types'
import { UPCOMING_EVENTS } from './upcomingEvents'

function relativeDate(days: number, hour = 18) {
  const date = new Date(2027, 0, 15, hour, 0, 0)
  date.setDate(date.getDate() + days)
  return date.toISOString()
}

export function createSeedEvents(): CommunityEvent[] {
  const seeds = [
{id:'social-1',type:'alumni',title:'Coffee & familiar faces',description:'Meet fellow alumni over a relaxed cup of coffee. Share what you are working on, swap stories and welcome a few new faces. Everyone is welcome — just bring your curiosity.',location:'Munich Urban Colab · Café',start:relativeDate(3,10),end:relativeDate(3,12),author:'Maya · Alumni community',color:'peach',art:'Coffee first.\nConnections next.',reviews:[]},
{id:'social-2',type:'hobby',title:'Sunday Walk & Talk',description:'A gentle walk through the English Garden with the community. Bring comfortable shoes and something warm to drink. We will meet at the main entrance.',location:'English Garden · Main entrance',start:relativeDate(6,11),end:relativeDate(6,13),author:'Jonas · Class of 2023',color:'blue',art:'Fresh air.\nFresh perspectives.',reviews:[]},
{id:'social-3',type:'party',title:'Alumni Autumn Social',description:'An evening of music, snacks and catching up with alumni from different cohorts. Thank you to everyone who joined us!',location:'Community Lounge · Munich',start:relativeDate(-4,18),end:relativeDate(-4,22),author:'Common Ground team',color:'lilac',art:'Same community.\nNew memories.',reviews:[{id:'sample-review',name:'Alex · Alumni',text:'Such a lovely evening! It was great to meet people from other cohorts.',photos:[],date:relativeDate(-3,10)}]},
{id:'official-1',type:'job',title:'Product & Growth Intern',description:'Sprout is looking for a curious student to help with product discovery and growth experiments. Part-time, 3–6 months. Share a short introduction and your portfolio with the team at the next community meetup.',location:'Munich · Hybrid',start:relativeDate(0,9),end:relativeDate(21,18),author:'Sprout · Climate tech startup',color:'',art:'Small team.\nBig possibilities.',reviews:[]},
{id:'official-2',type:'cofounder',title:'Looking for a technical co-founder',description:'I am exploring a circular packaging startup and looking for a technical co-founder who enjoys turning ideas into prototypes. Let’s meet, compare our interests and see what we could build together.',location:'Munich · Flexible',start:relativeDate(0,9),end:relativeDate(30,18),author:'Maya · Founder',color:'lilac',art:'Two perspectives.\nOne big idea.',reviews:[]},
{id:'official-3',type:'official',title:'Pitch Practice Evening',description:'A friendly practice session for early-stage teams. Share your pitch and get feedback from alumni and educators.',location:'Entrepreneurship Center',start:relativeDate(-7,17),end:relativeDate(-7,20),author:'Programme team',color:'',art:'Find your voice.\nShare your vision.',reviews:[]},
{id:'notice-1',type:'announcement',title:'Next cohort: organizer briefing',description:'Please join our internal briefing to confirm the welcome-session agenda, room assignments and mentoring schedule. Bring your latest planning notes.',location:'Meeting room 2 · Munich Urban Colab',start:relativeDate(2,9),end:relativeDate(2,10),author:'Programme coordination',color:'blue',art:'A little planning.\nA better programme.',reviews:[]},
{id:'notice-2',type:'announcement',title:'October retrospective',description:'Thank you for joining our organizer retrospective. Add your reflections so we can carry the lessons into the next cohort.',location:'Organizer workspace',start:relativeDate(-9,14),end:relativeDate(-9,15),author:'Programme coordination',color:'',art:'Reflect together.\nImprove together.',reviews:[]}
]
  return [
  ...UPCOMING_EVENTS,
  ...seeds.map<CommunityEvent>((event) => ({ ...event, topics: SEED_EVENT_TOPICS[event.id] ?? [], type: event.type as CommunityEvent['type'], authorId: event.author.includes('Maya') ? 'maya' : event.author.includes('Jonas') ? 'jonas' : event.author.includes('Sprout') ? 'alex' : 'organizer', audience: { mode: 'everyone', traits: [] } }))
]
}
