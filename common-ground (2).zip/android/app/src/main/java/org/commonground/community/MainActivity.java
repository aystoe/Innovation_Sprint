package org.commonground.community;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Capacitor SystemBars manages safe-area insets; do not add a second native padding layer.
        EdgeToEdge.enable(this);
    }
}
